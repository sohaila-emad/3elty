# BEAMFORM

## تشغيل

```bash
pip install flask flask-cors
python app.py
```

افتح: **http://localhost:5000**

---

## هيكل المشروع

```
beamform/
├── app.py              ← الباك اند (شغّله من هنا)
├── requirements.txt
├── data/
│   └── scenarios.json  ← بيتعمل تلقائي
└── frontend/
    ├── simulator.html
    ├── index.html
    ├── api-client.js   ← بيربط الفرونت بالباك اند
    └── ...
```

## API

| | المسار | الوظيفة |
|---|---|---|
| GET | `/api/scenarios` | كل السيناريوهات |
| POST | `/api/scenarios` | حفظ سيناريو |
| DELETE | `/api/scenarios/<key>` | حذف سيناريو |
| POST | `/api/physics/beam-pattern` | حساب Beam Pattern |
| POST | `/api/physics/steering-delays` | حساب Steering Delays |
| POST | `/api/physics/focusing-delays` | حساب Focusing Delays |
| GET | `/api/physics/window` | Apodization Weights |
