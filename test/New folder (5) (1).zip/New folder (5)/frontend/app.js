// ============================================================
// MAIN APPLICATION CONTROLLER
// BeamformingApp orchestrates all simulator modes.
// Pure OOP: owns simulator instances, delegates all physics
// to the simulator layer — no physics logic here.
// ============================================================

class BeamformingApp {
  // Private fields
  #currentSim = null;
  #currentModeName = null;
  #canvas = null;
  #sims = {};

  constructor() {
    this.#canvas = document.getElementById('sim-canvas');

    this._initTopActions();
    this._initModeTabs();
    this._handleResize();
    window.addEventListener('resize', () => this._handleResize());

    // Bus listener: toast relay from simulators
    Bus.on('ui:toast', msg => showToast(msg));
  }

  // ── Public API ────────────────────────────────────────────────

  /** Switch to a named mode. Idempotent: no-op if already active. */
  switchMode(modeName) {
    if (this.#currentSim) this.#currentSim.stop();

    document.querySelectorAll('[data-mode]').forEach(b =>
      b.classList.toggle('active', b.dataset.mode === modeName)
    );
    document.querySelectorAll('.ctrl-panel').forEach(p => p.classList.remove('active'));
    document.getElementById(`ctrl-${modeName}`)?.classList.add('active');

    // Ensure canvas is properly sized BEFORE creating the simulator,
    // so entity positions are calculated against real dimensions.
    this._handleResize();

    if (!this.#sims[modeName]) {
      this.#sims[modeName] = this._createSim(modeName);
    }

    this.#currentSim = this.#sims[modeName];
    this.#currentModeName = modeName;

    this._buildControls(modeName);
    this.#currentSim.start();
    this._buildScenarioList(modeName);
  }

  // Expose for simulator.html patch
  get currentSim() { return this.#currentSim; }
  get currentModeName() { return this.#currentModeName; }

  // ── Private: simulator factory ────────────────────────────────

  _createSim(modeName) {
    const cbs = {
      onParamChange: (p) => this._onParamChange(modeName, p),
      onEvent: (e) => this._onSimEvent(modeName, e)
    };
    switch (modeName) {
      case 'beamforming': return new BeamformingGenericMode(this.#canvas, cbs);
      case 'ultrasound': return new UltrasoundMode(this.#canvas, cbs);
      case 'fiveg': return new FiveGMode(this.#canvas, cbs);
      case 'radar': return new RadarMode(this.#canvas, cbs);
      default: throw new Error(`Unknown mode: ${modeName}`);
    }
  }

  // ── Private: event handlers ───────────────────────────────────

  _onParamChange(modeName, params) {
    // 1. التحديث الخاص بمود البيم فورمينج (الجديد)
    if (modeName === 'beamforming') {
      _setSliderVal('bf-steer', params.steerAngle, '°');
      // بنحول التردد لـ GHz عشان السلايدر يفهمه
      _setSliderVal('bf-freq', (params.frequency / 1e9).toFixed(1), 'GHz');
      _setSliderVal('bf-elements', params.numElements);
      _setSliderVal('bf-spacing', params.spacing);
      _setSliderVal('bf-amp', params.amplitude.toFixed(1));
    }

    // 2. التحديث الخاص بمود الـ Ultrasound (القديم)
    if (modeName === 'ultrasound') {
      _setSliderVal('us-steer', params.steerAngle, '°');
      _setSliderVal('us-focal', Math.round(params.focalDepth), 'mm');
    }
  }

  _onSimEvent(modeName, evt) {
    const messages = {
      placed_tower: '📡 Tower placed',
      placed_user: '📱 User added',
      removed: '🗑 Removed'
    };
    if (messages[evt]) showToast(messages[evt]);
  }

  // ── Private: resize ───────────────────────────────────────────

  _handleResize() {
    const wrap = this.#canvas.parentElement;
    this.#canvas.style.width = wrap.clientWidth + 'px';
    this.#canvas.style.height = wrap.clientHeight + 'px';
    if (this.#currentSim?.renderer) {
      this.#currentSim.renderer.resize();
      if (this.#currentModeName === 'ultrasound') {
        this.#currentSim._rebuildArray();
      }
    }
  }

  // ── Private: tab init ─────────────────────────────────────────

  _initModeTabs() {
    document.querySelectorAll('[data-mode]').forEach(btn =>
      btn.addEventListener('click', () => this.switchMode(btn.dataset.mode))
    );
  }

  // ── Private: top-bar actions ──────────────────────────────────

  _initTopActions() {
    // Save scenario
    document.getElementById('btn-save-scenario')?.addEventListener('click', async () => {
      if (!this.#currentSim || !this.#currentModeName) return;
      const name = prompt('Scenario name:');
      if (!name) return;
      const key = `custom_${name.replace(/\s+/g, '_').toLowerCase()}_${Date.now()}`;

      let scenarioParams = { ...this.#currentSim.params };
      const mode = this.#currentModeName;
      if (mode === 'fiveg') {
        scenarioParams.towers = this.#currentSim.towers.map(t => t.serialize());
        scenarioParams.users = this.#currentSim.users.map(u => u.serialize());
      } else if (mode === 'radar') {
        scenarioParams.targets = this.#currentSim.targets.map(t => t.serialize());
      }

      await ScenarioManager.save(key, {
        mode, name,
        description: 'Custom saved scenario',
        params: scenarioParams
      });
      this._buildScenarioList(mode);
      showToast('💾 Scenario saved!');
    });

    // Export JSON
    document.getElementById('btn-export')?.addEventListener('click', () => {
      if (!this.#currentSim) return;
      const state = this.#currentSim.getState();
      const data = JSON.stringify(state, null, 2);
      const blob = new Blob([data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = `bf_state_${this.#currentModeName}.json`; a.click();
      URL.revokeObjectURL(url);
      showToast('📥 JSON exported');
    });
  }

  // ── Private: control panel builders ──────────────────────────

  _buildControls(modeName) {
    switch (modeName) {
      case 'beamforming': this._buildBeamformingControls(); break; // 👈 ضيفي دي
      case 'ultrasound': this._buildUltrasoundControls(); break;
      case 'fiveg': this._build5GControls(); break;
      case 'radar': this._buildRadarControls(); break;
    }
  }
  _buildBeamformingControls() {
    const panel = document.getElementById('ctrl-beamforming');
    if (!panel || panel.dataset.built) return;
    panel.dataset.built = 'true';

    // 1. حقن الـ HTML الخاص بالسلايدرز
    panel.innerHTML = `
    <div class="ctrl-section">
      <h3 class="ctrl-title">GENERAL ARRAY SPECS</h3>
      ${_slider('bf-elements', 'Elements', 2, 128, 16, 1)}
      ${_slider('bf-spacing', 'd/λ Spacing', 0.1, 1, 0.5, 0.01)}
      ${_slider('bf-freq', 'Frequency', 1, 10, 2.4, 0.1, 'GHz')}

      <h3 class="ctrl-title">SIGNAL CONTROL</h3>
      ${_slider('bf-steer', 'Steering Angle', -90, 90, 0, 1, '°')}
      ${_slider('bf-amp', 'Amplitude', 0, 2, 1, 0.1)}
      ${_slider('bf-phase', 'Phase Offset', -180, 180, 0, 1, '°')}

      <h3 class="ctrl-title">APODIZATION</h3>
      <div class="btn-group">
        <button class="btn-sm active" data-bf-win="none">Rect</button>
        <button class="btn-sm" data-bf-win="hanning">Hann</button>
        <button class="btn-sm" data-bf-win="hamming">Hamm</button>
        <button class="btn-sm" data-bf-win="blackman">Black</button>
        <button class="btn-sm" data-bf-win="kaiser">Kaiser</button>
      </div>
      ${_slider('bf-kaiser', 'Kaiser β', 1, 15, 6, 0.5)}

      <h3 class="ctrl-title">NOISE</h3>
      ${_slider('bf-snr', 'SNR', 0, 1000, 100, 10)}
    </div>
  `;

    // 2. ربط الـ Event Listeners (السر هنا!)
    // بنستخدم الدوال المساعدة اللي إنتي كاتباها في آخر الملف
    _bindSlider('bf-elements', v => this.currentSim?.setParams({ numElements: +v }));
    _bindSlider('bf-spacing', v => this.currentSim?.setParams({ spacing: parseFloat(v) }));
    _bindSlider('bf-freq', v => this.currentSim?.setParams({ frequency: parseFloat(v) * 1e9 }));
    _bindSlider('bf-steer', v => this.currentSim?.setParams({ steerAngle: parseFloat(v) }));
    _bindSlider('bf-amp', v => this.currentSim?.setParams({ amplitude: parseFloat(v) }));
    _bindSlider('bf-phase', v => this.currentSim?.setParams({ phase: parseFloat(v) }));
    _bindSlider('bf-kaiser', v => this.currentSim?.setParams({ kaiserBeta: parseFloat(v) }));
    _bindSlider('bf-snr', v => this.currentSim?.setParams({ snr: parseFloat(v) }));

    // ربط أزرار الـ Apodization
    panel.querySelectorAll('[data-bf-win]').forEach(btn => {
      btn.addEventListener('click', () => {
        panel.querySelectorAll('[data-bf-win]').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.currentSim?.setParams({ windowType: btn.dataset.bfWin });
      });
    });
  }
  _buildUltrasoundControls() {
    const panel = document.getElementById('ctrl-ultrasound');
    if (!panel || panel.dataset.built) return;
    panel.dataset.built = 'true';

    panel.innerHTML = `
      <div class="ctrl-section">

        <h3 class="ctrl-title">🩻 SCAN MODE</h3>
        <div class="ctrl-group">
          <div class="btn-group">
            <button class="btn-sm active" data-us-mode="beamform">Beam</button>
            <button class="btn-sm" data-us-mode="amode">A-Mode</button>
            <button class="btn-sm" data-us-mode="bmode">B-Mode</button>
            <button class="btn-sm" data-us-mode="doppler">Doppler</button>
            <button class="btn-sm" style="color:#ffaa00; border-color:rgba(255,170,0,0.4);" data-us-mode="interf">~ Interf.</button>
          </div>
          <p class="hint">Drag canvas to steer beam</p>
        </div>

        <h3 class="ctrl-title">🔊 ARRAY SETUP</h3>
        ${_slider('us-elements', 'Elements', 4, 128, 32, 4)}
        ${_slider('us-freq', 'Frequency', 1, 15, 5, 0.5, 'MHz')}
        ${_slider('us-spacing', 'Spacing', 0.1, 1.5, 0.25, 0.05, 'mm')}
        ${_slider('us-steer', 'Steer Angle', -60, 60, 0, 1, '°')}
        ${_slider('us-focal', 'Focal Depth', 20, 200, 100, 5, 'mm')}
        <div class="ctrl-group">
          <label class="ctrl-label">Array Type</label>
          <div class="btn-group">
            <button class="btn-sm active" data-us-array="linear">Linear</button>
            <button class="btn-sm" data-us-array="curved">Curved</button>
          </div>
        </div>
        ${_slider('us-curv', 'Curve Radius', 30, 150, 70, 5, 'mm')}

        <h3 class="ctrl-title">🪟 APODIZATION</h3>
        <div class="ctrl-group">
          <label class="ctrl-label">Window Function</label>
          <div class="btn-group" style="flex-wrap:wrap;gap:3px">
            <button class="btn-sm active" data-us-apod="none">Rect</button>
            <button class="btn-sm" data-us-apod="hanning">Hann</button>
            <button class="btn-sm" data-us-apod="hamming">Hamm</button>
            <button class="btn-sm" data-us-apod="blackman">Black</button>
            <button class="btn-sm" data-us-apod="kaiser">Kaiser</button>
          </div>
          <p class="hint">Reduces sidelobes at cost of main-lobe width</p>
        </div>
        ${_slider('us-kaiser', 'Kaiser β', 1, 15, 6, 0.5, '')}

        <h3 class="ctrl-title">📶 SIGNAL</h3>
        ${_slider('us-snr', 'SNR', 0, 1000, 100, 10, '')}

        <h3 class="ctrl-title">🩸 DOPPLER / VESSEL</h3>
        ${_slider('us-bloodvel', 'Blood Velocity', 0, 2, 0.5, 0.05, 'm/s')}
        ${_slider('us-vesselangle', 'Vessel Angle', 0, 90, 30, 1, '°')}

        <h3 class="ctrl-title">👁 DISPLAY</h3>
        <div class="ctrl-group">
          <div class="toggle-row">
            ${_toggle('us-indiv', 'Individual Waves', true)}
            ${_toggle('us-beam', 'Beam Profile', true)}
            ${_toggle('us-heatmap', 'Heatmap', true)}
            ${_toggle('us-focus', 'Focusing', true)}
            ${_toggle('us-phantom', 'Show Phantom', true)}
            ${_toggle('us-vessel', 'Show Vessel', true)}
          </div>
        </div>
      </div>`;

    panel.querySelectorAll('[data-us-mode]').forEach(b =>
      b.addEventListener('click', () => {
        panel.querySelectorAll('[data-us-mode]').forEach(x => x.classList.remove('active'));
        b.classList.add('active');
        const sim = this.#sims.ultrasound;
        if (!sim) return;
        sim.setScanMode(b.dataset.usMode);
        if (b.dataset.usMode === 'bmode') showToast('Building B-Mode scan…');
      })
    );

    _bindSlider('us-elements', v => this.#currentSim?.setParams({ numElements: +v }));
    _bindSlider('us-freq', v => this.#currentSim?.setParams({ frequency: parseFloat(v) * 1e6 }));
    _bindSlider('us-spacing', v => this.#currentSim?.setParams({ spacing: parseFloat(v) }));
    _bindSlider('us-steer', v => this.#currentSim?.setParams({ steerAngle: parseFloat(v) }));
    _bindSlider('us-focal', v => this.#currentSim?.setParams({ focalDepth: parseFloat(v) }));
    _bindSlider('us-curv', v => this.#currentSim?.setParams({ curvatureRadius: parseFloat(v) }));

    panel.querySelectorAll('[data-us-array]').forEach(b =>
      b.addEventListener('click', () => {
        panel.querySelectorAll('[data-us-array]').forEach(x => x.classList.remove('active'));
        b.classList.add('active');
        this.#currentSim?.setParams({ arrayType: b.dataset.usArray });
      })
    );

    panel.querySelectorAll('[data-us-apod]').forEach(b =>
      b.addEventListener('click', () => {
        panel.querySelectorAll('[data-us-apod]').forEach(x => x.classList.remove('active'));
        b.classList.add('active');
        this.#currentSim?.setParams({ apodization: b.dataset.usApod });
        showToast(`Window: ${b.dataset.usApod}`);
      })
    );
    _bindSlider('us-kaiser', v => this.#currentSim?.setParams({ kaiserBeta: parseFloat(v) }));
    _bindSlider('us-snr', v => this.#currentSim?.setParams({ snr: parseFloat(v) }));
    _bindSlider('us-bloodvel', v => this.#currentSim?.setParams({ bloodVelocity: parseFloat(v) }));
    _bindSlider('us-vesselangle', v => this.#currentSim?.setParams({ vesselAngle: parseFloat(v) }));

    _bindToggle('us-indiv', v => this.#currentSim?.setParams({ showIndividual: v }));
    _bindToggle('us-beam', v => this.#currentSim?.setParams({ showBeam: v }));
    _bindToggle('us-heatmap', v => this.#currentSim?.setParams({ showHeatmap: v }));
    _bindToggle('us-focus', v => this.#currentSim?.setParams({ focusing: v }));
    _bindToggle('us-phantom', v => this.#currentSim?.setParams({ showPhantom: v }));
    _bindToggle('us-vessel', v => this.#currentSim?.setParams({ showVessel: v }));
  }

  _build5GControls() {
    const panel = document.getElementById('ctrl-fiveg');
    if (!panel || panel.dataset.built) return;
    panel.dataset.built = 'true';

    panel.innerHTML = `
      <div class="ctrl-section">
        <h3 class="ctrl-title">📡 5G BASE STATION</h3>

        <!-- ── Tower Editor (shown only when a tower is selected) ── -->
        <div class="ctrl-group tower-editor" id="fg-tower-editor" style="display:none;">
          <div class="tower-editor-header">
            <span id="fg-tower-editor-title">✎ TOWER 1</span>
            <button class="tower-editor-close" id="fg-tower-editor-close" title="Deselect">✕</button>
          </div>
          ${_slider('fg-t-elements', 'Antenna Elements', 4, 64, 16, 4)}
          ${_slider('fg-t-freq',     'Frequency',        1, 60, 28, 1, 'GHz')}
          <p class="hint">Coverage is calculated from frequency</p>
          ${_slider('fg-t-snr',      'SNR',              0, 1000, 100, 10)}
          <button class="btn-action danger" id="fg-t-remove" style="margin-top:6px;">🗑 Remove This Tower</button>
        </div>

        <!-- ── Global defaults (all towers) ── -->
        <div class="ctrl-group" id="fg-global-section">
          <label class="ctrl-label" style="opacity:0.5; font-size:9px; letter-spacing:.08em;">DEFAULT FOR NEW TOWERS</label>
          ${_slider('fg-elements', 'Antenna Elements', 4, 64, 16, 4)}
          ${_slider('fg-freq', 'Frequency', 1, 60, 28, 1, 'GHz')}
          <p class="hint">Coverage follows frequency</p>
          ${_slider('fg-snr', 'SNR', 0, 1000, 100, 10)}
        </div>

        <div class="ctrl-group">
          <label class="ctrl-label">Placement</label>
          <div class="btn-group-v">
            <button class="btn-action" id="fg-add-tower">📡 Add Tower (T)</button>
            <button class="btn-action" id="fg-add-user">📱 Add User (U)</button>
            <button class="btn-action danger" id="fg-rem-user">🗑 Remove Selected (Shift+Click)</button>
          </div>
        </div>

        <div class="ctrl-group">
          <label class="ctrl-label">Move Selected User</label>
          <div class="dpad" id="fg-dpad">
            <div></div><button data-dir="up">▲</button><div></div>
            <button data-dir="left">◄</button><div></div><button data-dir="right">►</button>
            <div></div><button data-dir="down">▼</button><div></div>
          </div>
          <p class="hint">Select user then arrow keys or D-pad</p>
        </div>

        <div class="ctrl-group">
          <label class="ctrl-label">Display</label>
          <div class="toggle-row">
            ${_toggle('fg-beams', 'Show Beams', true)}
            ${_toggle('fg-coverage', 'Coverage Area', true)}
            ${_toggle('fg-elems', 'Antenna Elements', true)}
            ${_toggle('fg-infoboxes', 'Tower Info Boxes', true)}
          </div>
        </div>

        <div class="ctrl-group">
          <button class="btn-action" id="fg-analysis-btn" style="width:100%;background:rgba(0,180,255,0.12);border-color:rgba(0,180,255,0.4);">📊 Analysis View</button>
        </div>
      </div>`;

    const fg = () => this.#sims.fiveg;

    _bindSlider('fg-elements', v => {
      const n = +v;
      fg()?.setParams({ numElements: n });
      fg()?.towers.forEach(t => { t.numElements = n; });
    });
    _bindSlider('fg-freq', v => {
      const f = parseFloat(v) * 1e9;
      fg()?.setParams({ frequency: f });
      fg()?.towers.forEach(t => { t.frequency = f; });
    });
    _bindSlider('fg-snr', v => {
      const s = parseFloat(v);
      fg()?.setParams({ snr: s });
      fg()?.towers.forEach(t => { t.snr = s; });
    });

    document.getElementById('fg-add-tower')?.addEventListener('click', () => fg()?.startPlacingTower());
    document.getElementById('fg-add-user')?.addEventListener('click', () => fg()?.startPlacingUser());
    document.getElementById('fg-rem-user')?.addEventListener('click', () => fg()?.removeSelectedUser());

    _bindToggle('fg-beams', v => fg()?.setParams({ showBeams: v }));
    _bindToggle('fg-coverage', v => fg()?.setParams({ showCoverage: v }));
    _bindToggle('fg-elems', v => fg()?.setParams({ showElements: v }));
    _bindToggle('fg-infoboxes', v => fg()?.setParams({ showInfoBoxes: v }));

    document.getElementById('fg-dpad')?.addEventListener('mousedown', e => {
      const btn = e.target.closest('[data-dir]');
      const u = fg()?.selectedUser;
      if (!btn || !u) return;
      const spd = 6;
      const map = { up: [0, -spd], down: [0, spd], left: [-spd, 0], right: [spd, 0] };
      const [dx, dy] = map[btn.dataset.dir] || [0, 0];
      u.move(dx, dy);
    });

    // ── Tower Editor: show/hide + populate on tower selection ─────
    const editorEl  = document.getElementById('fg-tower-editor');
    const globalEl  = document.getElementById('fg-global-section');
    const titleEl   = document.getElementById('fg-tower-editor-title');

    const _setSliderVal = (id, val) => {
      const el = document.getElementById(id);
      if (!el) return;
      el.value = val;
      el.dispatchEvent(new Event('input'));          // update displayed value label
      el.dispatchEvent(new Event('_label_only'));    // in case _bindSlider uses a separate label
      // Manually update sibling value display (pattern used by _slider helper)
      const lbl = el.closest('.ctrl-group, .slider-row')?.querySelector('.slider-val, .val-label, output');
      if (lbl) lbl.textContent = val;
    };

    const showTowerEditor = (tower, towerIndex) => {
      if (!tower) {
        editorEl.style.display  = 'none';
        globalEl.style.display  = '';
        return;
      }
      editorEl.style.display  = '';
      globalEl.style.display  = 'none';
      titleEl.textContent = `✎ TOWER ${towerIndex + 1}`;

      // Populate sliders with this tower's current values
      _setSliderVal('fg-t-elements', tower.numElements);
      _setSliderVal('fg-t-freq',     (tower.frequency / 1e9).toFixed(0));
      _setSliderVal('fg-t-snr',      tower.snr ?? fg()?.params.snr ?? 100);
    };

    // Listen for tower selection from canvas click
    Bus.on('fiveg:tower_selected', tower => {
      const idx = tower ? fg()?.towers.indexOf(tower) : -1;
      showTowerEditor(tower, idx);
    });

    // Tower editor slider bindings — affect ONLY the selected tower
    _bindSlider('fg-t-elements', v => {
      const t = fg()?.selectedTower; if (!t) return;
      fg()?.updateTower(t, { numElements: +v });
    });
    _bindSlider('fg-t-freq', v => {
      const t = fg()?.selectedTower; if (!t) return;
      fg()?.updateTower(t, { frequency: parseFloat(v) * 1e9 });
    });
    _bindSlider('fg-t-snr', v => {
      const t = fg()?.selectedTower; if (!t) return;
      fg()?.updateTower(t, { snr: parseFloat(v) });
    });

    document.getElementById('fg-tower-editor-close')?.addEventListener('click', () => {
      fg()?.selectTower(null);
    });

    document.getElementById('fg-t-remove')?.addEventListener('click', () => {
      const t = fg()?.selectedTower;
      if (t) { fg()?.removeTower(t); fg()?.selectTower(null); }
    });

    document.getElementById('fg-analysis-btn')?.addEventListener('click', () => {
      this._openAnalysisModal();
    });
  }

  // ── Analysis Modal ────────────────────────────────────────────
  _openAnalysisModal() {
    const fg = this.#sims.fiveg;
    if (!fg || fg.towers.length === 0) {
      Bus.emit('ui:toast', 'Add at least one tower first');
      return;
    }

    // Remove existing modal if open
    document.getElementById('fg-analysis-modal')?.remove();

    const modal = document.createElement('div');
    modal.id = 'fg-analysis-modal';
    modal.innerHTML = `
      <div class="analysis-overlay" id="fg-analysis-overlay"></div>
      <div class="analysis-panel">
        <div class="analysis-header">
          <span>📊 Beam Analysis</span>
          <button class="analysis-close" id="fg-analysis-close">✕</button>
        </div>
        <div class="analysis-body" id="fg-analysis-body"></div>
      </div>`;
    document.body.appendChild(modal);

    document.getElementById('fg-analysis-overlay')?.addEventListener('click', () => modal.remove());
    document.getElementById('fg-analysis-close')?.addEventListener('click',   () => modal.remove());

    this._renderAnalysisViewers(fg);

    // Live update loop — redraws every 200ms while modal is open
    const interval = setInterval(() => {
      if (!document.getElementById('fg-analysis-modal')) { clearInterval(interval); return; }
      this._renderAnalysisViewers(fg);
    }, 200);
  }

  _renderAnalysisViewers(fg) {
    const body = document.getElementById('fg-analysis-body');
    if (!body) return;

    // Rebuild tower viewers
    body.innerHTML = '';
    fg.towers.forEach((tower, tIdx) => {
      const wrap = document.createElement('div');
      wrap.className = 'analysis-tower-wrap';
      const steerUser = tower.activeUsers[0];
      const steerAngle = steerUser ? MathUtils.angleTo(tower, steerUser) : 0;
      const wl = SPEED_OF_LIGHT / tower.frequency;
      const spacing = MathUtils.fiveGElementSpacing();
      const bwDeg = MathUtils.beamwidth3dB(tower.numElements, spacing, wl) * 180 / Math.PI;
      const effectiveRange = Math.round(tower.effectiveRange || tower.range);
      wrap.innerHTML = `
        <div class="analysis-tower-title">
          <span class="analysis-dot ${tower.activeUsers.length > 0 ? 'active' : ''}"></span>
          TOWER ${tIdx + 1} — ${(tower.frequency/1e9).toFixed(0)} GHz · ${tower.numElements} ant · ${effectiveRange}px coverage · ${bwDeg.toFixed(1)}° beam
        </div>
        <div class="analysis-canvases">
          <div class="analysis-viewer">
            <div class="analysis-viewer-label">2D Interference Map</div>
            <canvas class="analysis-heatmap" width="220" height="220" data-tower="${tIdx}"></canvas>
          </div>
          <div class="analysis-viewer">
            <div class="analysis-viewer-label">Beam Profile</div>
            <canvas class="analysis-polar" width="220" height="220" data-tower="${tIdx}"></canvas>
          </div>
          <div class="analysis-viewer">
            <div class="analysis-viewer-label">AF vs Angle</div>
            <canvas class="analysis-linear" width="300" height="220" data-tower="${tIdx}"></canvas>
          </div>
          <div class="analysis-viewer">
            <div class="analysis-viewer-label">Field Map</div>
            <canvas class="analysis-fieldmap" width="300" height="220" data-tower="${tIdx}"></canvas>
          </div>
        </div>`;
      body.appendChild(wrap);

      // Draw immediately
      this._drawHeatmap(wrap.querySelector('.analysis-heatmap'), tower, fg);
      this._drawPolar(wrap.querySelector('.analysis-polar'), tower, fg);
      this._drawLinear(wrap.querySelector('.analysis-linear'), tower, fg);
      this._drawFieldMap(wrap.querySelector('.analysis-fieldmap'), tower, fg);
    });
  }

  _drawHeatmap(canvas, tower, fg) {
    const ctx = canvas.getContext('2d');
    const W = canvas.width, H = canvas.height;
    const img = ctx.createImageData(W, H);
    const cx = W / 2, cy = H / 2;
    const effectiveRange = tower.effectiveRange || tower.range;
    const scale = (effectiveRange * 2) / W;   // world-px per canvas-px

    const wl  = SPEED_OF_LIGHT / tower.frequency;
    const d   = MathUtils.fiveGElementSpacing();
    const N   = tower.numElements;

    const steerAngle = tower.activeUsers.length > 0
      ? MathUtils.angleTo(tower, tower.activeUsers[0])
      : 0;
    const visualLambdaPx = Math.max(6, effectiveRange / 18);

    // For each canvas pixel, compute signed constructive/destructive field.
    for (let py = 0; py < H; py++) {
      for (let px = 0; px < W; px++) {
        const wx = (px - cx) * scale;
        const wy = (py - cy) * scale;
        const dist = Math.sqrt(wx*wx + wy*wy);
        const theta = Math.atan2(wy, wx);
        const sinDiff = Math.sin(theta) - Math.sin(steerAngle);
        let re = 0, im = 0;
        for (let n = 0; n < N; n++) {
          const arrayPhase = (2 * Math.PI * d / wl) * n * sinDiff;
          const radialPhase = (2 * Math.PI * dist) / visualLambdaPx;
          const phase = arrayPhase + radialPhase;
          re += Math.cos(phase);
          im += Math.sin(phase);
        }
        const fade = Math.exp(-2.2 * (dist / Math.max(effectiveRange, 1)) ** 1.45);
        const signedField = (re / N) * fade;       // -1..1
        const af = Math.abs(signedField);          // 0..1

        const i4 = (py * W + px) * 4;
        if (signedField >= 0) {
          const t = Math.min(1, af / 0.8);
          img.data[i4]   = Math.round(5 + t * 190);
          img.data[i4+1] = Math.round(30 + t * 220);
          img.data[i4+2] = Math.round(70 + t * 185);
        } else {
          const t = Math.min(1, af / 0.8);
          img.data[i4]   = Math.round(30 + t * 225);
          img.data[i4+1] = Math.round(20 + t * 95);
          img.data[i4+2] = Math.round(55 - t * 35);
        }
        img.data[i4+3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);

    // Draw tower center dot
    ctx.beginPath();
    ctx.arc(cx, cy, 4, 0, Math.PI*2);
    ctx.fillStyle = '#ffcc33';
    ctx.fill();

    // Draw steering direction and effective coverage ring.
    ctx.save();
    ctx.strokeStyle = 'rgba(255,200,50,0.6)';
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(cx + Math.cos(steerAngle) * (W / 2 - 8), cy + Math.sin(steerAngle) * (H / 2 - 8));
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.strokeStyle = 'rgba(255,255,255,0.14)';
    ctx.beginPath();
    ctx.arc(cx, cy, W / 2 - 10, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();

    // Draw user positions relative to tower
    tower.activeUsers.forEach(user => {
      const ux = cx + (user.x - tower.x) / scale;
      const uy = cy + (user.y - tower.y) / scale;
      ctx.beginPath();
      ctx.arc(ux, uy, 4, 0, Math.PI*2);
      ctx.fillStyle = user.color;
      ctx.fill();
    });

    ctx.fillStyle = 'rgba(180,220,255,0.55)';
    ctx.font = '8px monospace';
    ctx.textAlign = 'left';
    ctx.fillText('+ constructive', 6, 12);
    ctx.fillStyle = 'rgba(255,150,80,0.65)';
    ctx.fillText('- destructive', 6, 22);
  }

  _drawPolar(canvas, tower, fg) {
    const ctx = canvas.getContext('2d');
    const W = canvas.width, H = canvas.height;
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#05101f';
    ctx.fillRect(0, 0, W, H);

    const cx = W / 2, cy = H / 2;
    const R  = W / 2 - 14;

    const wl = SPEED_OF_LIGHT / tower.frequency;
    const d  = MathUtils.fiveGElementSpacing();
    const N  = tower.numElements;
    const beamwidth = MathUtils.beamwidth3dB(N, d, wl);
    const beamwidthDeg = beamwidth * 180 / Math.PI;
    const steerAngle = tower.activeUsers.length > 0
      ? MathUtils.angleTo(tower, tower.activeUsers[0])
      : 0;

    // Grid rings
    ctx.strokeStyle = 'rgba(0,150,255,0.15)';
    ctx.lineWidth   = 0.5;
    [0.25, 0.5, 0.75, 1].forEach(r => {
      ctx.beginPath();
      ctx.arc(cx, cy, R * r, 0, Math.PI*2);
      ctx.stroke();
    });
    // Spokes
    for (let a = 0; a < Math.PI*2; a += Math.PI/6) {
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + Math.cos(a)*R, cy + Math.sin(a)*R);
      ctx.stroke();
    }

    // Beam pattern
    const steps = 360;
    ctx.beginPath();
    for (let i = 0; i <= steps; i++) {
      const theta = (i / steps) * Math.PI * 2 - Math.PI;
      const sinDiff = Math.sin(theta) - Math.sin(steerAngle);
      let re = 0, im = 0;
      for (let n = 0; n < N; n++) {
        const phase = (2 * Math.PI * d / wl) * n * sinDiff;
        re += Math.cos(phase);
        im += Math.sin(phase);
      }
      const af = Math.sqrt(re*re + im*im) / N;
      const r  = af * R;
      const px = cx + Math.cos(theta) * r;
      const py = cy + Math.sin(theta) * r;
      i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
    }
    ctx.closePath();
    const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, R);
    grad.addColorStop(0,   'rgba(0,200,255,0.5)');
    grad.addColorStop(0.6, 'rgba(0,150,255,0.3)');
    grad.addColorStop(1,   'rgba(0,100,200,0.1)');
    ctx.fillStyle = grad;
    ctx.fill();
    ctx.strokeStyle = '#00ccff';
    ctx.lineWidth   = 1.5;
    ctx.stroke();

    // Steer direction line
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(cx + Math.cos(steerAngle)*R, cy + Math.sin(steerAngle)*R);
    ctx.strokeStyle = 'rgba(255,200,50,0.6)';
    ctx.lineWidth   = 1;
    ctx.setLineDash([3,3]);
    ctx.stroke();
    ctx.setLineDash([]);

    // Approximate -3 dB beam edges.
    ctx.strokeStyle = 'rgba(255,200,50,0.35)';
    ctx.lineWidth = 0.8;
    ctx.setLineDash([2, 4]);
    [-0.5, 0.5].forEach(sign => {
      const edge = steerAngle + sign * beamwidth;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + Math.cos(edge) * R, cy + Math.sin(edge) * R);
      ctx.stroke();
    });
    ctx.setLineDash([]);

    // Labels
    ctx.fillStyle   = 'rgba(100,180,255,0.5)';
    ctx.font        = '9px monospace';
    ctx.textAlign   = 'center';
    ctx.fillText('0°',  cx,      cy - R - 4);
    ctx.fillText('180°', cx,     cy + R + 12);
    ctx.fillText('90°',  cx + R + 4, cy + 3);
    ctx.fillText('-90°', cx - R - 4, cy + 3);
    ctx.textAlign = 'left';
    ctx.fillStyle = 'rgba(255,220,120,0.75)';
    ctx.fillText(`BW ${beamwidthDeg.toFixed(1)}°`, 8, 14);
  }

  _drawLinear(canvas, tower, fg) {
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const W = canvas.width, H = canvas.height;
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#05101f';
    ctx.fillRect(0, 0, W, H);

    const PAD_L = 36, PAD_R = 10, PAD_T = 12, PAD_B = 28;
    const plotW = W - PAD_L - PAD_R;
    const plotH = H - PAD_T - PAD_B;

    const wl = SPEED_OF_LIGHT / tower.frequency;
    const d  = MathUtils.fiveGElementSpacing();
    const N  = tower.numElements;
    const steerAngle = tower.activeUsers.length > 0
      ? MathUtils.angleTo(tower, tower.activeUsers[0])
      : 0;

    const steps = 360;
    const afs = [];
    for (let i = 0; i <= steps; i++) {
      const theta = ((i / steps) * 180 - 90) * Math.PI / 180;
      const sinDiff = Math.sin(theta) - Math.sin(steerAngle);
      let re = 0, im = 0;
      for (let n = 0; n < N; n++) {
        const phase = (2 * Math.PI * d / wl) * n * sinDiff;
        re += Math.cos(phase);
        im += Math.sin(phase);
      }
      afs.push(Math.sqrt(re * re + im * im) / N);
    }

    ctx.strokeStyle = 'rgba(0,150,255,0.12)';
    ctx.lineWidth = 0.5;
    [0, 0.25, 0.5, 0.75, 1].forEach(v => {
      const y = PAD_T + plotH * (1 - v);
      ctx.beginPath(); ctx.moveTo(PAD_L, y); ctx.lineTo(PAD_L + plotW, y); ctx.stroke();
      ctx.fillStyle = 'rgba(100,180,255,0.45)';
      ctx.font = '9px monospace'; ctx.textAlign = 'right';
      ctx.fillText((v * 100).toFixed(0) + '%', PAD_L - 3, y + 3);
    });
    [-90, -60, -30, 0, 30, 60, 90].forEach(a => {
      const x = PAD_L + ((a + 90) / 180) * plotW;
      ctx.strokeStyle = 'rgba(0,150,255,0.12)';
      ctx.beginPath(); ctx.moveTo(x, PAD_T); ctx.lineTo(x, PAD_T + plotH); ctx.stroke();
      ctx.fillStyle = 'rgba(100,180,255,0.45)';
      ctx.font = '9px monospace'; ctx.textAlign = 'center';
      ctx.fillText(a + '°', x, PAD_T + plotH + 14);
    });

    ctx.beginPath();
    ctx.moveTo(PAD_L, PAD_T + plotH);
    afs.forEach((af, i) => {
      const x = PAD_L + (i / steps) * plotW;
      const y = PAD_T + plotH * (1 - af);
      ctx.lineTo(x, y);
    });
    ctx.lineTo(PAD_L + plotW, PAD_T + plotH);
    ctx.closePath();
    ctx.fillStyle = 'rgba(0,200,255,0.07)';
    ctx.fill();

    ctx.beginPath();
    afs.forEach((af, i) => {
      const x = PAD_L + (i / steps) * plotW;
      const y = PAD_T + plotH * (1 - af);
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.strokeStyle = 'rgba(0,200,255,0.9)';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    const steerDeg = steerAngle * 180 / Math.PI;
    const sx = PAD_L + ((steerDeg + 90) / 180) * plotW;
    ctx.strokeStyle = 'rgba(255,200,50,0.7)';
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 3]);
    ctx.beginPath(); ctx.moveTo(sx, PAD_T); ctx.lineTo(sx, PAD_T + plotH); ctx.stroke();
    ctx.setLineDash([]);

    ctx.fillStyle = 'rgba(100,180,255,0.55)';
    ctx.font = '9px monospace'; ctx.textAlign = 'center';
    ctx.fillText('Angle →', PAD_L + plotW / 2, H - 2);
  }

  _drawFieldMap(canvas, tower, fg) {
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const W = canvas.width, H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    const wl = SPEED_OF_LIGHT / tower.frequency;
    const d  = MathUtils.fiveGElementSpacing();
    const N  = tower.numElements;
    const steerAngle = tower.activeUsers.length > 0
      ? MathUtils.angleTo(tower, tower.activeUsers[0])
      : 0;

    // Array is at bottom-center; field fans upward (like image 1)
    const originX = W / 2;
    const originY = H;
    const maxDist = Math.sqrt(W * W + H * H);

    const img = ctx.createImageData(W, H);

    for (let py = 0; py < H; py++) {
      for (let px = 0; px < W; px++) {
        const dx = px - originX;
        const dy = originY - py;   // flip Y so up = positive
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 1) { continue; }

        // Only draw the forward half-space (above the array)
        if (dy < 0) {
          const i4 = (py * W + px) * 4;
          img.data[i4] = img.data[i4+1] = img.data[i4+2] = 5;
          img.data[i4+3] = 255;
          continue;
        }

        const theta = Math.atan2(dx, dy);   // angle from broadside (up)
        const sinDiff = Math.sin(theta) - Math.sin(steerAngle);
        let re = 0, im = 0;
        for (let n = 0; n < N; n++) {
          const phase = (2 * Math.PI * d / wl) * n * sinDiff;
          re += Math.cos(phase);
          im += Math.sin(phase);
        }
        const af = Math.sqrt(re * re + im * im) / N;  // 0..1

        // Distance fade
        const fade = Math.max(0.2, 1 - dist / maxDist * 0.7);

        const i4 = (py * W + px) * 4;
        if (af > 0.55) {
          // Constructive — cyan/white
          const t = (af - 0.55) / 0.45;
          img.data[i4]   = Math.round(fade * (t * 180));
          img.data[i4+1] = Math.round(fade * (120 + t * 135));
          img.data[i4+2] = Math.round(fade * 255);
        } else if (af > 0.2) {
          // Transition — orange/amber like image 1
          const t = (af - 0.2) / 0.35;
          img.data[i4]   = Math.round(fade * (120 + t * 80));
          img.data[i4+1] = Math.round(fade * (40 + t * 60));
          img.data[i4+2] = Math.round(fade * 20);
        } else {
          // Destructive — deep blue/dark
          const t = af / 0.2;
          img.data[i4]   = Math.round(fade * 5);
          img.data[i4+1] = Math.round(fade * (t * 30));
          img.data[i4+2] = Math.round(fade * (15 + t * 60));
        }
        img.data[i4+3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);

    // Draw array elements along bottom
    const elSpacing = Math.min(W / (N + 1), 12);
    const arrayW = elSpacing * (N - 1);
    for (let n = 0; n < N; n++) {
      const ex = originX - arrayW / 2 + n * elSpacing;
      ctx.beginPath();
      ctx.arc(ex, H - 3, 2, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(0,220,255,0.8)';
      ctx.fill();
    }

    // Steer direction line
    const sx = originX + Math.sin(steerAngle) * (H - 10);
    const sy = originY - Math.cos(steerAngle) * (H - 10);
    ctx.strokeStyle = 'rgba(255,200,50,0.6)';
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(originX, H);
    ctx.lineTo(Math.max(0, Math.min(W, sx)), Math.max(0, sy));
    ctx.stroke();
    ctx.setLineDash([]);

    // Label
    ctx.fillStyle = 'rgba(100,180,255,0.5)';
    ctx.font = '9px monospace';
    ctx.textAlign = 'left';
    ctx.fillText('constructive/destructive', 5, 12);
  }

  _buildRadarControls() {
    const panel = document.getElementById('ctrl-radar');
    if (!panel || panel.dataset.built) return;
    panel.dataset.built = 'true';

    panel.innerHTML = `
      <div class="ctrl-section">
        <h3 class="ctrl-title">🎯 RADAR SYSTEM</h3>
        ${_slider('rd-elements', 'Array Elements', 4, 64, 24, 4)}
        ${_slider('rd-freq', 'Frequency', 1, 30, 9, 0.5, 'GHz')}
        ${_slider('rd-speed', 'Scan Speed', 0.1, 3, 0.5, 0.05, 'rad/s')}
        ${_slider('rd-range', 'Range', 100, 500, 280, 10, 'px')}
        ${_slider('rd-bw', 'Beam Width', 1, 30, 5, 0.5, '°')}
        ${_slider('rd-snr', 'SNR', 0, 1000, 100, 10)}

        <div class="ctrl-group">
          <label class="ctrl-label">Target Size (selected)</label>
          ${_slider('rd-tsize', 'RCS / Size', 1, 30, 8, 0.5, 'm²')}
          <p class="hint" id="rd-tsize-hint">Click a target on scope to select it</p>
        </div>

        <div class="ctrl-group">
          <label class="ctrl-label">Scan Mode</label>
          <div class="btn-group">
            <button class="btn-sm active" data-rd-mode="scan">360° Scan</button>
            <button class="btn-sm" data-rd-mode="track">Track</button>
          </div>
        </div>

        <h3 class="ctrl-title">🪟 APODIZATION</h3>
        <div class="ctrl-group">
          <label class="ctrl-label">Window Function</label>
          <div class="btn-group" style="flex-wrap:wrap;gap:3px">
            <button class="btn-sm" data-rd-win="none">Rect</button>
            <button class="btn-sm" data-rd-win="hanning">Hann</button>
            <button class="btn-sm active" data-rd-win="hamming">Hamm</button>
            <button class="btn-sm" data-rd-win="blackman">Black</button>
            <button class="btn-sm" data-rd-win="kaiser">Kaiser</button>
          </div>
        </div>

        <div class="ctrl-group">
          <label class="ctrl-label">Targets (≤5)</label>
          <p class="hint">Click scope → add · Drag target → move · Right-click → remove · Del key → remove selected</p>
          <div class="btn-group-v">
            <button class="btn-action danger" id="rd-delete-selected">🗑 Delete Selected Target</button>
            <button class="btn-action danger" id="rd-clear">🗑 Clear All Targets</button>
          </div>
        </div>

        <div class="ctrl-group">
          <label class="ctrl-label">Display</label>
          <div class="toggle-row">
            ${_toggle('rd-sidelobes', 'Show Sidelobes', true)}
            ${_toggle('rd-compare', 'Classic vs BF', false)}
          </div>
        </div>
      </div>`;

    _bindSlider('rd-elements', v => {
      const n = +v;
      this.#currentSim?.setParams({ numElements: n });
      // Internal mathematical link: N dictates Beam Width
      const spacing = this.#currentSim?.params.spacing || 0.5;
      const bwRad = 0.886 / (n * spacing);
      const bwDeg = Math.max(1, Math.min(30, bwRad * 180 / Math.PI));
      this.#currentSim?.setParams({ beamWidthDeg: bwDeg });
      // Note: per requirements, do NOT update the rd-bw slider visually
    });

    let lastFreq = this.#currentSim?.params.frequency || 9e9;
    _bindSlider('rd-freq', v => {
      const newFreq = parseFloat(v) * 1e9;
      this.#currentSim?.setParams({ frequency: newFreq });

      // Internal mathematical link: Frequency changes Beam Width
      const currentBw = this.#currentSim?.params.beamWidthDeg || 5;
      let newBw = currentBw * (lastFreq / newFreq);
      newBw = Math.max(1, Math.min(30, newBw));

      this.#currentSim?.setParams({ beamWidthDeg: newBw });
      lastFreq = newFreq;

      // Note: per requirements, do NOT update rd-bw slider visually, and do NOT change scan speed
    });
    _bindSlider('rd-speed', v => this.#currentSim?.setParams({ scanSpeed: parseFloat(v) }));
    _bindSlider('rd-range', v => this.#currentSim?.setParams({ scanRange: parseFloat(v) }));
    _bindSlider('rd-bw', v => this.#currentSim?.setParams({ beamWidthDeg: parseFloat(v) }));
    _bindSlider('rd-snr', v => this.#currentSim?.setParams({ snr: parseFloat(v) }));

    // Target size slider — modifies selected target
    _bindSlider('rd-tsize', v => {
      const rd = this.#sims.radar;
      if (rd?.selectedTarget) {
        rd.selectedTarget.rcs = parseFloat(v);
        rd.selectedTarget.size = parseFloat(v);
      }
    });

    panel.querySelectorAll('[data-rd-mode]').forEach(b =>
      b.addEventListener('click', () => {
        panel.querySelectorAll('[data-rd-mode]').forEach(x => x.classList.remove('active'));
        b.classList.add('active');
        this.#currentSim?.setParams({ trackingMode: b.dataset.rdMode === 'track' });
      })
    );

    panel.querySelectorAll('[data-rd-win]').forEach(b =>
      b.addEventListener('click', () => {
        panel.querySelectorAll('[data-rd-win]').forEach(x => x.classList.remove('active'));
        b.classList.add('active');
        this.#currentSim?.setParams({ windowType: b.dataset.rdWin });
        showToast(`Window: ${b.dataset.rdWin}`);
      })
    );

    document.getElementById('rd-delete-selected')?.addEventListener('click', () => {
      const rd = this.#sims.radar;
      if (rd?.selectedTarget) {
        rd.removeTarget(rd.selectedTarget);
        showToast('🗑 Target removed');
      } else {
        showToast('⚠️ No target selected');
      }
    });

    document.getElementById('rd-clear')?.addEventListener('click', () => {
      this.#sims.radar?.clearTargets();
      showToast('🗑 Targets cleared');
    });

    _bindToggle('rd-sidelobes', v => this.#currentSim?.setParams({ showSidelobes: v }));
    _bindToggle('rd-compare', v => this.#currentSim?.setParams({ showComparison: v }));

    // Listen for target selection from radar mode
    Bus.on('radar:target_selected', t => {
      if (t) {
        _setSliderVal('rd-tsize', t.rcs.toFixed(1), 'm²');
        const el = document.getElementById('rd-tsize');
        if (el) el.value = t.rcs;
        const hint = document.getElementById('rd-tsize-hint');
        if (hint) hint.textContent = `Target selected — RCS = ${t.rcs.toFixed(0)} m²`;
      } else {
        const hint = document.getElementById('rd-tsize-hint');
        if (hint) hint.textContent = 'Click a target on scope to select it';
      }
    });
  }

  // ── Private: scenario panel ───────────────────────────────────

  async _buildScenarioList(modeName) {
    const list = document.getElementById('scenario-list');
    if (!list) return;
    list.innerHTML = '<div style="color:var(--muted);font-size:11px;padding:4px 0">Loading…</div>';

    // getByMode may be sync (before api-client patch) or async (after patch)
    // Await handles both cases safely
    let scenarios = {};
    try {
      const result = ScenarioManager.getByMode(modeName);
      scenarios = (result && typeof result.then === 'function') ? await result : result;
    } catch (e) {
      console.warn('ScenarioManager.getByMode error:', e);
    }
    list.innerHTML = '';

    Object.entries(scenarios).forEach(([key, s]) => {
      const wrap = document.createElement('div');
      wrap.style.cssText = 'position:relative;margin-bottom:3px';

      const btn = document.createElement('button');
      btn.className = 'scenario-btn';
      const isCustom = !!s.custom;
      btn.innerHTML = `<strong>${s.name}${isCustom ? ' ✎' : ''}</strong><span>${s.description}</span>`;
      btn.style.paddingRight = isCustom ? '30px' : '';
      btn.addEventListener('click', () => {
        list.querySelectorAll('.scenario-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this._loadScenario(key, modeName);
      });
      wrap.appendChild(btn);

      if (isCustom) {
        const del = document.createElement('button');
        del.title = 'Delete scenario';
        del.textContent = '✕';
        del.style.cssText = 'position:absolute;top:50%;right:6px;transform:translateY(-50%);background:rgba(255,60,60,0.1);border:1px solid rgba(255,60,60,0.25);color:#ff6666;border-radius:3px;width:18px;height:18px;cursor:pointer;font-size:10px;display:flex;align-items:center;justify-content:center;padding:0;font-family:monospace;line-height:1';
        del.addEventListener('click', async e => {
          e.stopPropagation();
          if (confirm(`Delete "${s.name}"?`)) {
            await ScenarioManager.remove(key);
            this._buildScenarioList(modeName);
            showToast('🗑 Scenario deleted');
          }
        });
        wrap.appendChild(del);
      }
      list.appendChild(wrap);
    });
  }

  async _loadScenario(key, modeName) {
    const scenario = await ScenarioManager.loadAsync(key);
    if (!scenario) { showToast('⚠️ Scenario not found'); return; }

    if (modeName === 'beamforming') {
      this.#sims.beamforming?.setParams(scenario.params);
    }
    if (modeName === 'ultrasound') {
      this.#sims.ultrasound?.setParams(scenario.params);
    } else if (modeName === 'fiveg') {
      this.#sims.fiveg?._applyScenario(scenario);
    } else if (modeName === 'radar') {
      const p = { ...scenario.params };
      if (p.beamWidth !== undefined && p.beamWidthDeg === undefined) {
        p.beamWidthDeg = p.beamWidth; delete p.beamWidth;
      }
      this.#sims.radar?.setParams(p);
      if (scenario.params.targets) {
        this.#sims.radar.clearTargets();
        scenario.params.targets.forEach(t => this.#sims.radar.addTarget(t));
      }
      // Update UI sliders so they match the loaded scenario
      if (p.numElements !== undefined) _setSliderVal('rd-elements', p.numElements, '');
      if (p.beamWidthDeg !== undefined) _setSliderVal('rd-bw', p.beamWidthDeg, '°');
      if (p.scanSpeed !== undefined) _setSliderVal('rd-speed', p.scanSpeed, 'rad/s');
      if (p.scanRange !== undefined) _setSliderVal('rd-range', p.scanRange, 'px');
      if (p.frequency !== undefined) _setSliderVal('rd-freq', p.frequency / 1e9, 'GHz');
      if (p.snr !== undefined) _setSliderVal('rd-snr', p.snr, '');
    }
    showToast(`📂 Loaded: ${scenario.name}`);
  }
}

// ============================================================
// MODULE-PRIVATE UI HELPERS
// ============================================================

function _slider(id, label, min, max, def, step, unit = '') {
  const vid = `${id}-val`;
  const disp = step < 1 ? parseFloat(def).toFixed(1) : def;
  return `
    <div class="ctrl-group">
      <div class="ctrl-row">
        <label class="ctrl-label" for="${id}">${label}</label>
        <span class="ctrl-val" id="${vid}">${disp}${unit}</span>
      </div>
      <input type="range" class="ctrl-slider" id="${id}"
             min="${min}" max="${max}" value="${def}" step="${step}">
    </div>`;
}

function _toggle(id, label, defaultOn) {
  return `
    <label class="toggle-item">
      <input type="checkbox" id="${id}" ${defaultOn ? 'checked' : ''}>
      <span class="toggle-track"><span class="toggle-thumb"></span></span>
      <span class="toggle-label">${label}</span>
    </label>`;
}

function _bindSlider(id, cb) {
  const el = document.getElementById(id);
  const valEl = document.getElementById(`${id}-val`);
  if (!el) return;
  el.addEventListener('input', () => {
    cb(el.value);
    if (valEl) {
      const decimals = parseFloat(el.step) < 1 ? 1 : 0;
      const unit = valEl.textContent.replace(/[\d.\-]/g, '');
      valEl.textContent = parseFloat(el.value).toFixed(decimals) + unit;
    }
  });
}

function _setSliderVal(id, val, unit = '') {
  const el = document.getElementById(id);
  const valEl = document.getElementById(`${id}-val`);
  if (el) el.value = val;
  if (valEl) valEl.textContent = val + unit;
}

function _bindToggle(id, cb) {
  const el = document.getElementById(id);
  if (!el) return;
  el.addEventListener('change', () => cb(el.checked));
}

function showToast(msg) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => toast.classList.remove('show'), 2500);
}


// ── Boot ──────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  window._app = new BeamformingApp();
  window._app.switchMode('ultrasound');
});
