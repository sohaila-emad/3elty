// ============================================================
// SCENARIOS SHIM
// ScenarioManager is defined in system.js (single source of truth).
// This file exists only because simulator.html loads it by path.
// No code here — zero duplication.
// ============================================================
